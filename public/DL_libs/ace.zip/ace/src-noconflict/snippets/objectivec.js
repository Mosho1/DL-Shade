ace.define('ace/snippets/objectivec', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "objectivec";

});
